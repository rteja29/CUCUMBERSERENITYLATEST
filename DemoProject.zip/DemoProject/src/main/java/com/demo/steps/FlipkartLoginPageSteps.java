package com.demo.steps;

import com.demo.pages.FlipkartLoginPage;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class FlipkartLoginPageSteps extends ScenarioSteps{
	
	FlipkartLoginPage flipkartLoginPage;

	@Step
	public void loginToFlipkart(String username,String password)
	{
		flipkartLoginPage.loginIntoFlipkart(username, password);
	}
	
	@Step
	public void waitformilliseconds(int ms)
	{
		flipkartLoginPage.waitformilliseconds(ms);
	}
	
	@Step
	public void verifyLogin()
	{
		flipkartLoginPage.verifyLoggedInorNot();
	}
	
	@Step
	public void verifyInvalidCredentialsError() {
		
		flipkartLoginPage.verifyInvalidCredentialsError();
		
	}
	
	@Step
	public void closeBrowser() {
		flipkartLoginPage.closeBrowser();
		
	}
	
}
