package com.demo.stepdefinition;

import com.demo.steps.FlipkartLoginPageSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class FlipkartLoginPageStepDefinition {

	@Steps
	FlipkartLoginPageSteps fpSteps;
	
	@Given("^I login into flipkart application with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_into_flipkart_application_with_and(String username, String password) throws Throwable {
	   fpSteps.loginToFlipkart(username, password);
	}

	@Given("^I wait for (\\d+) seconds$")
	public void i_wait_for_seconds(int time) throws Throwable {
	    fpSteps.waitformilliseconds(time);
	}

	@Then("^I verify flipkart is logged in$")
	public void i_verify_flipkart_is_logged_in() throws Throwable {
	    fpSteps.verifyLogin();
	}

	@Then("^I close the browser$")
	public void i_close_the_browser() throws Throwable {
		fpSteps.closeBrowser();
	}

	@Then("^I verify invalid credentials error$")
	public void i_verify_invalid_credentials_error() throws Throwable {
	   fpSteps.verifyInvalidCredentialsError();
	}

}
