package com.demo.pages;

import org.junit.Assert;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class FlipkartLoginPage extends PageObject{

	@FindBy(xpath = "//input[@type='password']")
	public WebElementFacade txtbox_password;
	
	@FindBy(xpath = "(//input[@type='password']/../..//input)[1]")
	public WebElementFacade txtbox_username;
	
	@FindBy(xpath = "//button[@type='submit']/span")
	public WebElementFacade btn_Login;
	
	@FindBy(xpath = "//a[text()='Login']")
	public WebElementFacade txt_Login;
	
	@FindBy(xpath = "//span[text()='Please enter valid Email ID/Mobile number']")
	public WebElementFacade txt_invalidCredentials;

	public void waitformilliseconds(int seconds)
	{
		try {
			Thread.sleep(seconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void loginIntoFlipkart(String username, String password)
	{
		open();
		getDriver().manage().window().maximize();
		waitformilliseconds(3000);
		txtbox_username.sendKeys(username);
		txtbox_password.sendKeys(password);
		btn_Login.click();
		waitformilliseconds(3000);
	}

	public void verifyLoggedInorNot() {
		
		boolean flag = true;
		
		try {
			
			flag = txt_Login.isDisplayed();
		}catch(Exception e)
		{
			flag = false;
		}
		Assert.assertFalse(flag);
	}

	public void verifyInvalidCredentialsError() {
		
		boolean flag = false;
		try {
			
			flag = txt_invalidCredentials.isDisplayed();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		Assert.assertTrue("Verifying flag ",flag);
	}
	
	public void closeBrowser()
	{
		getDriver().quit();
	}
	
}
