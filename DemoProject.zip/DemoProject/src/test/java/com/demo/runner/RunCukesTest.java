package com.demo.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = { "src/test/resources/Features/" }, plugin = { "pretty", "html:target/cucumber",
		"json:target/json/cucumber.json" }, glue = { "com.demo.stepdefinition" }, tags = { "@FlipkartLogin" }, dryRun = false)

/***** Important Note ********/
/******
 * Comment this test if running in debug mode or if don't want to send Test
 * results to QA Dashboard
 ***********/
public class RunCukesTest {
	
	}

